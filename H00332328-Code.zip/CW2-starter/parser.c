/**
 * Solutions to Q2: Implement your Recursive Decent Parser here.
 * Note here you do not need to produce an AST as output.
 * 
 * Add helper functions/code as you wish.
 */

#include <stdio.h>
#include <stdlib.h>
#include "tokens.h"

//////////////////////////////////////////////////

// global variables

int symb;
extern void printSymb();
extern int yylex(void);
extern char *yytext;
extern FILE *yyin;
extern int symb;

//////////////////////////////////////////////////

// 
//----------------HELPER FUNCTIONS------------//
/**
 * Similar to showSymb() from the lecture notes. 
 */
char *getSymb(int s)
{  switch(s)
   {  
      case  ID: return "ID";
      case  INT: return "INT";
      /**
	   * add cases for more FUNC tokens here
	   */
     case METHOD:
        return "method";
    case RETURN:
        return "return";
    case VARS:
        return "vars";
    case BEGINS:
        return "begin";
    case ENDMETHOD:
        return "endmethod";
    case READ:
        return "read";
    case WRITE:
        return "write";
    case IF:
        return "if";
    case THEN:
        return "then";
    case ELSE:
        return "else";
    case ENDIF:
        return "endif";
    case WHILE:
        return "while";
    case ENDWHILE:
        return "endwhile";
    case LESS:
        return "less";
    case LESSEQ:
        return "lessEq";
    case EQ:
        return "eq";
    case NEQ:
        return "nEq";
    case SEMI:
        return ";";
    case COMMA:
        return ",";
    case LBR:
        return "(";
    case RBR:
        return ")";
    case ASSIGN:
        return ":=";
      case EOF: return "EOF";
      default: 
         printf("bad symbol: %d",s);
         return NULL;
   }
}

void printSymb()
{
    char *s;
    printf("%s ", getSymb(symb));
    if (symb == ID || symb == INT)
    {
        if (yytext == NULL)
        {
            printf("Error: yytext is null");
        }
        else
        {
            printf("%s\n", yytext);
        }
    }
    else
    {
        printf("\n");
    }
}

void error(char * rule, char * message)
{  printf("%s: found %s\n",rule,getSymb(symb));
   printf("%s: %s\n",rule,message);
   exit(0);
}





//-------------YOUR CODE BELOW THIS LINE----------------------//

void program();
void methods();
void method();
void args();
void statements();
void statement();
void rw();
void assign();
void if_statement(); // Had to add _statement because of c's if
void while_loop();   // Had to add _loop because of c's while
void cond();
void bop();
void exprs(); // Changed to exprs because of below.
void expr();  // Had to change to expr because of error.

/**
 * To get the next symbol
 */
void lex()
{
    symb = yylex();
    printSymb();
}

/**
 *  This is where parser execution begins: it's the method for parsing programs.
 */ 
void program()
{
	// lex the program
    lex();

    // If symbol is method, call methods, else print error
    if (symb == METHOD)
    {
        methods();
    }
    else
    {
        error("program", "Symbol must be method");
    }
}

/**
 * 
 * YOUR CODE HERE
 * Add methods corresponding to the Non-terminals in the FUNC grammar below here
 * 
 */



//////////////////////////////////////////////////

void methods()
{
    // call method
    method();

    // If next symbol is method, call methods again
    if (symb == METHOD)
    {
        methods();
    }
}

/**
 * <method> ::= method <id>([<args>]) [vars <args>] 
 *      begin <statements> [return <id>;] endmethod
 */
void method()
{
    // Lex method
    lex();

    // Check symb is ID
    if (symb != ID)
    {
        error("method name", "Name is not a valid ID. \nA valid ID starts with a letter.");
    }
    // lex the id
    lex();

    // Check that next symb is (
    if (symb != LBR)
    {
        error("method args", "Missing (");
    }
    // Lex (
    lex();

    // Check that next symb is args
    if (symb == ID)
    {
        // Call the args
        args();
    }

    // Check that next symb is )
    if (symb != RBR)
    {
        error("method args", "Missing )");
    }
    // Lex )
    lex();

    // Check if next symb is vars
    if (symb == VARS)
    {
        // lex vars and call args
        lex();
        args();
    }

    // Check that next symb is begins
    if (symb != BEGINS)
    {
        error("method start", "The method must start with 'begin' after the declartion of vars");
    }
    // Lex begin
    lex();

    // Call the statements in the body
    statements();

    // Check if next symb is return
    if (symb == RETURN)
    {
        // lex return
        lex();

        // Symb must be an ID.
        if (symb != ID)
        {
            error("method return", "The return value must be an ID.\nA valid ID starts with a letter.");
        }
        else
        {
            // lex return value
            lex();
        }
        // Symb must be a semi colon
        if (symb != SEMI)
        {
            error("method return", "return value must be followed by a ;");
        }
        // Lex ;
        lex();
    }
    // Check that next symb is endmethod
    if (symb != ENDMETHOD)
    {
        error("end of method", "a method must end with 'endmethod'");
    }
    // lex endmethod
    lex();

    // Last symb must be ;
    if (symb != SEMI)
    {
        error("missing ;", "endmethod must be followed by ; ");
    }
    // lex ;
    lex();
}

/**
 * <args> ::= <id>[,<args>] 
 */
void args()
{
    // lex name
    lex();

    // Check if symbol is comma
    if (symb == COMMA)
    {
        // lex comma, and call args again
        lex();
        args();
    }
}

/**
 * <statements> ::= <statement>;[<statements>]
 */
void statements()
{
    // Call statement
    statement();

    // Check if symb is SEMI
    if (symb == SEMI)
    {
        // lex ;
        lex();

        // Check next symb
        if (symb == ID || symb == IF || symb == WHILE || symb == READ || symb == WRITE)
        {
            // Call statements again
            statements();
        }
    }
    else
    {
        error("statements error, missing ;", "A statement must end with a ;");
    }
}

/**
 * <statement> ::= <assign> | <if> | <while> | <rw>
 */
void statement()
{
    // Switch on the symbol, and call the correct statement
    switch (symb)
    {
    case ID:
        assign();
        break;
    case IF:
        if_statement();
        break;
    case WHILE:
        while_loop();
        break;
    case READ:
        rw();
        break;
    case WRITE:
        rw();
        break;
    default:
        error("statement", "ASSIGN / IF / WHILE / READ / WRITE identifier expected");
    }
}

/**
 * <rw> ::= read <id> | write <exp>
 */
void rw()
{
    // If sym is read
    if (symb == READ)
    {
        // lex read
        lex();

        // check that symb is id
        if (symb != ID)
        {
            error("read error", "read must be followed by an ID\nA valid ID starts with a letter.");
        }
        // lex the id
        lex();
    }
    // if symb is write
    else if (symb == WRITE)
    {
        // lex write and call expression
        lex();
        expr();
    }
    else
    {
        error("rw", "Symbol not READ or WRITE\n");
    }
}

/**
 * <assign> ::= <id> := <exp>
 */
void assign()
{
    // lex the id
    lex();

    // Check symb is ASSIGN
    if (symb != ASSIGN)
    {
        error("assign", "expected assign symbol, :=\n");
    }
    // Lex assign and call expresion
    lex();
    expr();
}

/**
 * <if> ::= if <cond> then <statements> [else <statements>] endif
 */
void if_statement()
{
    // lex if
    lex();

    // call condition
    cond();

    // Check that next symbol is then
    if (symb != THEN)
    {
        error("if then error", "expected then after the if condition");
    }
    // lex THEN
    lex();

    // Call statements
    statements();

    // Check if there is ELSE
    if (symb == ELSE)
    {
        // lex else and call statements
        lex();
        statements();
    }
    // Must end with endif
    if (symb != ENDIF)
    {
        error("endif", "If statement must end with 'endif'");
    }
    // lex endif
    lex();
}

/**
 * <while> ::= while <cond> begin <statements> endwhile
 */
void while_loop()
{
    // lex while and call condition
    lex();
    cond();

    // Check loop start with begin
    if (symb != BEGINS)
    {
        error("while loop error", "Loop must start with begin");
    }
    // lex begin and call statements
    lex();
    statements();

    // Check that the while loop ends with endwhile
    if (symb != ENDWHILE)
    {
        error("while loop error", "Loop must end with endwhile");
    }
    // lex endloop
    lex();
}

/**
 * <cond> ::= <bop> ( <exps> )
 */
void cond()
{
    // call bop
    bop();

    // Check that bop is followed by a (
    if (symb != LBR)
    {
        error("condition error", "Missing (");
    }
    // Lex (
    lex();

    // call expressions
    exprs();

    // Check that it ends with )
    if (symb != RBR)
    {
        error("condition error", "Missing )");
    }
    // Lex )
    lex();
}

/**
 * <bop> ::= less | lessEq | eq | nEq
 */
void bop()
{
    // Switch on the symbol
    switch (symb)
    {
    case LESS:
    case LESSEQ:
    case EQ:
    case NEQ:
        break;
    default:
        error("bop error", "Binary Operation not valid. Valid binary operators: less, lessEq, eq, nEq");
    }
    // Lex the symb
    lex();
}

/**
 * <exps> ::= <exp> [,<exps>]
 */
void exprs()
{
    // Call expression
    expr();

    // Check if more
    if (symb == COMMA)
    {
        // lex comma and call expressions
        lex();
        exprs();
    }
}

/**
 * <exp> ::= <id>[( <exps> )] | <int>
 */
void expr()
{
    // Check ID
    if (symb == ID)
    {
        // lex the id
        lex();

        // Check (
        if (symb == LBR)
        {
            // Lex (
            lex();

            // Call expressions
            exprs();

            // Check that followed by )
            if (symb != RBR)
            {
                error("expression error", "Missing )");
            }
            lex();
        }
    }
    // Else check if it is a number
    else if (symb == INT)
    {
        // lex the number
        lex();
    }
    else
    {
        error("expression error", "Must be ID or INT.\nA valid ID starts with a letter.\nA valid number is all numbers from 0 and up");
    }
}

//////////////////////////////////////////////////

/**
 * Execution starts here
 */
int main(int argc, char **argv)
{
    // open the file to be parsed, if possible
    if ((yyin = fopen(argv[1], "r")) == NULL)
    {
        printf("can't open %s\n", argv[1]);
        exit(0);
    }

    program();

    fclose(yyin);
}