
/** 
 *  This file should contain all the token definitions your lexer will use
 *   as well as any other constants you might want to define.
*/

///////////////// Your token definitions below this line. Two of them already defined for you.
//

#define ID 1
#define INT 2
#define METHOD 3
#define RETURN 4
#define VARS 5
#define BEGINS 6
#define ENDMETHOD 7
#define READ 8
#define WRITE 9
#define IF 10
#define THEN 11
#define ELSE 12
#define ENDIF 13
#define WHILE 14
#define ENDWHILE 15
#define LBR 16
#define RBR 17
#define LESS 18
#define LESSEQ 19
#define EQ 20
#define NEQ 21
#define SEMI 22
#define COMMA 23
#define ASSIGN 24